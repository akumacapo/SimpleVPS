#!/bin/bash
# Auto-Kill Inteligente - Anti multi-login con deteccion padre/hijo
DB="/etc/SimpleVPS/db/users.db"
LOG="/etc/SimpleVPS/tmp/autokill.log"
source /etc/SimpleVPS/lib/funcoes.sh 2>/dev/null

while true; do
  [[ ! -f $DB ]] && { sleep 15; continue; }
  while IFS='|' read -r user pass expira limite creado status; do
    [[ -z $user || "$status" == "blocked" ]] && continue

    # Contar procesos sshd del usuario (sesiones reales, excluir padre listener)
    pids=$(ps -u "$user" -o pid=,ppid=,comm= 2>/dev/null | awk '$3 ~ /sshd|dropbear/{print $1}')
    # Filtrar: solo procesos hijos de sesiones (no el daemon)
    count=0
    declare -A parents
    for pid in $pids; do
      ppid=$(awk '{print $4}' /proc/$pid/stat 2>/dev/null)
      # Si el padre es sshd/dropbear daemon o 1, es sesion
      pcomm=$(ps -p $ppid -o comm= 2>/dev/null)
      if [[ "$pcomm" =~ ^(sshd|dropbear|systemd)$ ]] || [[ "$ppid" == "1" ]]; then
        ((count++))
      fi
    done
    # Fallback: contar por ss -tnp o who
    if [[ $count -eq 0 ]]; then
      count=$(who 2>/dev/null | grep -c "^${user} " || echo 0)
    fi
    # Otro fallback
    count2=$(ps aux 2>/dev/null | grep -E "sshd: ${user}@|dropbear.*${user}" | grep -v grep | wc -l)
    [[ $count2 -gt $count ]] && count=$count2

    if [[ $count -gt $limite ]]; then
      echo "$(date '+%F %T') AUTO-KILL $user ($count > $limite)" >> $LOG
      # Matar las conexiones extras (dejar solo $limite)
      ps aux 2>/dev/null | grep -E "sshd: ${user}@" | grep -v grep | awk '{print $2}' | \
        tail -n +$((limite+1)) | xargs -r kill -9 2>/dev/null
      pkill -u "$user" -f "sshd" 2>/dev/null
      tg_send "⚠️ <b>Auto-Kill</b>%0AUser: <code>$user</code>%0AConexiones: $count/$limite%0AExtras terminadas"
    fi

    # Expirados
    hoy=$(date +%Y-%m-%d)
    if [[ "$expira" < "$hoy" ]]; then
      pkill -u "$user" 2>/dev/null
      passwd -l "$user" 2>/dev/null
    fi
  done < $DB
  sleep 20
done
