#!/bin/bash
# Notificaciones Telegram de logins SSH
source /etc/SimpleVPS/lib/funcoes.sh 2>/dev/null
LOG=/var/log/auth.log
[[ ! -f $LOG ]] && LOG=/var/log/secure
[[ ! -f $LOG ]] && exit 0

tail -Fn0 "$LOG" 2>/dev/null | while read line; do
  if echo "$line" | grep -qE "Accepted (password|publickey)"; then
    user=$(echo "$line" | grep -oP 'for \K\S+')
    ip=$(echo "$line" | grep -oP 'from \K[\d.]+')
    tg_send "🔓 <b>Login SSH</b>%0AUser: <code>$user</code>%0AIP: <code>$ip</code>%0A$(date '+%F %T')"
  fi
  if echo "$line" | grep -qE "Failed password"; then
    user=$(echo "$line" | grep -oP 'for \K\S+' | head -1)
    ip=$(echo "$line" | grep -oP 'from \K[\d.]+')
    tg_send "🚫 <b>Login fallido</b>%0AUser: <code>$user</code>%0AIP: <code>$ip</code>"
  fi
done
