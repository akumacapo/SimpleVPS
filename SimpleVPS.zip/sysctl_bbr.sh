#!/bin/bash
# Optimizacion de Red: BBR + Sysctl automatico
GREEN='\033[1;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
echo -e "${YELLOW}[*] Aplicando optimizacion de red...${NC}"

modprobe tcp_bbr 2>/dev/null
echo "tcp_bbr" > /etc/modules-load.d/bbr.conf 2>/dev/null

cat > /etc/sysctl.d/99-simplevps.conf << 'SYS'
# BBR
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
# Buffers
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
net.core.rmem_default = 65536
net.core.wmem_default = 65536
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_tw_reuse = 1
net.ipv4.ip_local_port_range = 1024 65535
net.core.netdev_max_backlog = 250000
net.core.somaxconn = 4096
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_max_tw_buckets = 5000
# Seguridad basica
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv6.conf.all.accept_redirects = 0
SYS

sysctl -p /etc/sysctl.d/99-simplevps.conf &>/dev/null
echo -e "${GREEN}[✓] BBR + Sysctl aplicados${NC}"
sysctl net.ipv4.tcp_congestion_control net.core.default_qdisc 2>/dev/null
