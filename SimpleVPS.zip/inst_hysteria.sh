#!/bin/bash
# Hysteria v1 - Puerto 36712 con ofuscacion
set -e
RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'; BLUE='\033[1;36m'; NC='\033[0m'
DIR="/etc/SimpleVPS"
HY_DIR="/etc/hysteria"
PORT=36712

echo -e "${YELLOW}[*] Instalando Hysteria v1...${NC}"
arch=$(uname -m)
case $arch in
  x86_64) arch="amd64" ;;
  aarch64) arch="arm64" ;;
  *) echo -e "${RED}Arquitectura no soportada: $arch${NC}"; exit 1 ;;
esac

mkdir -p $HY_DIR
# Hysteria v1 binary
if [[ ! -f /usr/local/bin/hysteria ]]; then
  wget -qO /tmp/hysteria "https://github.com/HyNetwork/hysteria/releases/download/v1.3.5/hysteria-linux-${arch}" 2>/dev/null \
    || wget -qO /tmp/hysteria "https://github.com/apernet/hysteria/releases/download/v1.3.5/hysteria-linux-${arch}" 2>/dev/null
  if [[ -f /tmp/hysteria ]]; then
    mv /tmp/hysteria /usr/local/bin/hysteria
    chmod +x /usr/local/bin/hysteria
  else
    echo -e "${RED}[!] No se pudo descargar Hysteria${NC}"
    exit 1
  fi
fi

# Certificado
if [[ ! -f $HY_DIR/server.crt ]]; then
  openssl req -x509 -nodes -newkey ec:<(openssl ecparam -name prime256v1) \
    -keyout $HY_DIR/server.key -out $HY_DIR/server.crt -subj "/CN=hysteria" -days 3650 2>/dev/null
fi

# Password aleatorio
PASS=$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 16)
OBFS=$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 12)

cat > $HY_DIR/config.json << HYEOF
{
  "listen": ":${PORT}",
  "protocol": "udp",
  "cert": "${HY_DIR}/server.crt",
  "key": "${HY_DIR}/server.key",
  "obfs": "${OBFS}",
  "alpn": "h3",
  "auth": {
    "mode": "password",
    "config": {
      "password": "${PASS}"
    }
  },
  "up_mbps": 1000,
  "down_mbps": 1000,
  "recv_window_conn": 33554432,
  "recv_window": 83886080
}
HYEOF

cat > /etc/systemd/system/hysteria.service << 'SYSEOF'
[Unit]
Description=Hysteria v1 Server
After=network.target
[Service]
Type=simple
ExecStart=/usr/local/bin/hysteria -c /etc/hysteria/config.json server
Restart=always
RestartSec=3
LimitNOFILE=1048576
[Install]
WantedBy=multi-user.target
SYSEOF

systemctl daemon-reload
systemctl enable hysteria &>/dev/null
systemctl restart hysteria &>/dev/null

IP=$(curl -s --max-time 3 ipv4.icanhazip.com 2>/dev/null || hostname -I | awk '{print $1}')
echo -e "${GREEN}[✓] Hysteria v1 instalado${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  IP:       ${YELLOW}${IP}${NC}"
echo -e "  Puerto:   ${YELLOW}${PORT}${NC} (UDP)"
echo -e "  Password: ${YELLOW}${PASS}${NC}"
echo -e "  Obfs:     ${YELLOW}${OBFS}${NC}"
echo -e "  ALPN:     ${YELLOW}h3${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "${PASS}|${OBFS}|${PORT}" > $DIR/db/hysteria.conf
