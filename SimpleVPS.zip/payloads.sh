#!/bin/bash
# Generador de Payloads - SimpleVPS
RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'; BLUE='\033[1;36m'; WHITE='\033[1;37m'; NC='\033[0m'
IP=$(curl -s --max-time 3 ipv4.icanhazip.com 2>/dev/null || hostname -I | awk '{print $1}')

clear
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${YELLOW}       GENERADOR DE PAYLOADS${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -ne "  Host/SNI/IP [${IP}]: "; read HOST
[[ -z $HOST ]] && HOST="$IP"
echo -ne "  Puerto [80]: "; read PORT
[[ -z $PORT ]] && PORT=80
echo ""
echo -e "  ${GREEN}[1]${NC} WebSocket básico"
echo -e "  ${GREEN}[2]${NC} WebSocket + SSL (WSS)"
echo -e "  ${GREEN}[3]${NC} HTTP Injector / HTTP Custom"
echo -e "  ${GREEN}[4]${NC} Split / Bug host"
echo -e "  ${GREEN}[5]${NC} Payload Xray VMess/VLESS"
echo -e "  ${GREEN}[6]${NC} Todos"
echo -e "  ${RED}[0]${NC} Volver"
echo ""
echo -ne "  Opcion: "; read op

gen_ws(){
  echo -e "\n${YELLOW}══ WebSocket ══${NC}"
  echo -e "GET / HTTP/1.1[crlf]Host: ${HOST}[crlf]Upgrade: websocket[crlf]Connection: Keep-Alive[crlf][crlf]"
  echo -e "GET / HTTP/1.1[crlf]Host: ${HOST}[crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf][crlf]"
  echo -e "GET wss://${HOST}/ HTTP/1.1[crlf]Host: ${HOST}[crlf]Upgrade: websocket[crlf]Connection: Keep-Alive[crlf][crlf]"
}
gen_wss(){
  echo -e "\n${YELLOW}══ WSS / SSL ══${NC}"
  echo -e "GET / HTTP/1.1[crlf]Host: ${HOST}[crlf]Upgrade: websocket[crlf]Connection: Keep-Alive[crlf][crlf]"
  echo -e "CONNECT ${HOST}:443 HTTP/1.1[crlf]Host: ${HOST}[crlf][crlf]"
}
gen_http(){
  echo -e "\n${YELLOW}══ HTTP Injector / Custom ══${NC}"
  echo -e "GET http://${HOST}/ HTTP/1.1[crlf]Host: ${HOST}[crlf]X-Online-Host: ${HOST}[crlf]X-Forward-Host: ${HOST}[crlf]Connection: Keep-Alive[crlf][crlf]"
  echo -e "GET / HTTP/1.1[crlf]Host: ${HOST}[crlf]X-Online-Host: ${HOST}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf][crlf]"
  echo -e "CONNECT [host_port] HTTP/1.1[crlf]Host: ${HOST}[crlf][crlf]GET / HTTP/1.1[crlf]Host: ${HOST}[crlf]Connection: Keep-Alive[crlf][crlf]"
}
gen_split(){
  echo -e "\n${YELLOW}══ Split / Bug ══${NC}"
  echo -e "GET / HTTP/1.1[crlf]Host: ${HOST}[crlf][crlf]CONNECT [host_port] HTTP/1.1[crlf][crlf]"
  echo -e "GET http://${HOST}/ HTTP/1.1\nHost: ${HOST}\n\n"
  echo -e "GET / HTTP/1.1@[host_port][crlf]Host: ${HOST}[crlf][crlf]"
}
gen_xray(){
  UUID=$(cat /etc/SimpleVPS/db/xray.uuid 2>/dev/null || echo "UUID-NO-INSTALADO")
  echo -e "\n${YELLOW}══ Xray Links ══${NC}"
  echo -e "VMess WS:"
  echo -e "  Address: ${HOST}  Port: 80  UUID: ${UUID}  Path: /vmess  Net: ws  TLS: none"
  echo -e "VMess WSS:"
  echo -e "  Address: ${HOST}  Port: 443 UUID: ${UUID}  Path: /vmess  Net: ws  TLS: tls"
  echo -e "VLESS WS:"
  echo -e "  Address: ${HOST}  Port: 8082 UUID: ${UUID}  Path: /vless Net: ws  TLS: none"
  echo -e "Trojan:"
  echo -e "  Address: ${HOST}  Port: 8443 Pass: ${UUID}  Path: /trojan Net: ws  TLS: tls"
  echo -e "VLESS gRPC:"
  echo -e "  Address: ${HOST}  Port: 2053 UUID: ${UUID}  Service: grpc  TLS: tls"
  # Link vmess basico
  echo -e "\n${WHITE}Link VMess (raw data):${NC}"
  echo -e "vmess://(configurar en app con datos de arriba)"
}

case $op in
  1) gen_ws ;;
  2) gen_wss ;;
  3) gen_http ;;
  4) gen_split ;;
  5) gen_xray ;;
  6) gen_ws; gen_wss; gen_http; gen_split; gen_xray ;;
  0) exit 0 ;;
  *) exit 0 ;;
esac
echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -ne "  Enter..."; read
