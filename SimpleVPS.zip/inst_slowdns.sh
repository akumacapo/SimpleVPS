#!/bin/bash
# DNSTT / SlowDNS - Buffer Ext 512 / Int 1800
RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'; BLUE='\033[1;36m'; NC='\033[0m'
DIR="/etc/SimpleVPS"
SD_DIR="/etc/slowdns"

echo -e "${YELLOW}[*] Instalando SlowDNS (DNSTT)...${NC}"
mkdir -p $SD_DIR

arch=$(uname -m)
case $arch in x86_64) arch="amd64";; aarch64) arch="arm64";; *) arch="amd64";; esac

# dnstt-server binary (proyecto de talento/dnstt o similar)
if [[ ! -f /usr/local/bin/dnstt-server ]]; then
  # Fallback: usar slowdns de scripts comunitarios o compilar
  wget -qO /tmp/dnstt.tgz "https://www.bamsoftware.com/software/dnstt/dnstt-20211207.zip" 2>/dev/null || true
  # Intento con binario precompilado comun en comunidad
  wget -qO /usr/local/bin/dnstt-server "https://github.com/kaleemullah360/dnstt/raw/main/dnstt-server-linux-${arch}" 2>/dev/null || \
  wget -qO /usr/local/bin/dnstt-server "https://raw.githubusercontent.com/rudi9999/Herramientas/main/dnstt/dnstt-server" 2>/dev/null || true
  chmod +x /usr/local/bin/dnstt-server 2>/dev/null
fi

# Generar keys
if [[ ! -f $SD_DIR/server.key ]]; then
  if command -v dnstt-server &>/dev/null || [[ -x /usr/local/bin/dnstt-server ]]; then
    /usr/local/bin/dnstt-server -gen-key -privkey-file $SD_DIR/server.key -pubkey-file $SD_DIR/server.pub 2>/dev/null || {
      # Keys dummy si no se puede generar
      openssl rand -hex 32 > $SD_DIR/server.key
      openssl rand -hex 32 > $SD_DIR/server.pub
    }
  else
    openssl rand -hex 32 > $SD_DIR/server.key
    openssl rand -hex 32 > $SD_DIR/server.pub
  fi
fi

PUBKEY=$(cat $SD_DIR/server.pub 2>/dev/null | head -c 64)
NS_DOMAIN="slowdns.example.com"

echo -ne "  Dominio NS (ej: ns.tudominio.com): "; read NS_DOMAIN
[[ -z $NS_DOMAIN ]] && NS_DOMAIN="ns.example.com"

# Puerto SSH local al que redirige
SSH_PORT=22

cat > /etc/systemd/system/slowdns.service << SYSEOF
[Unit]
Description=SlowDNS DNSTT Server
After=network.target
[Service]
Type=simple
WorkingDirectory=${SD_DIR}
ExecStart=/usr/local/bin/dnstt-server -udp :5300 -privkey-file ${SD_DIR}/server.key ${NS_DOMAIN} 127.0.0.1:${SSH_PORT}
Restart=always
RestartSec=3
# Buffers
LimitNOFILE=65535
[Install]
WantedBy=multi-user.target
SYSEOF

# iptables redirect 53 -> 5300
iptables -t nat -C PREROUTING -p udp --dport 53 -j REDIRECT --to-ports 5300 2>/dev/null \
  || iptables -t nat -A PREROUTING -p udp --dport 53 -j REDIRECT --to-ports 5300 2>/dev/null
iptables -t nat -C PREROUTING -p tcp --dport 53 -j REDIRECT --to-ports 5300 2>/dev/null \
  || iptables -t nat -A PREROUTING -p tcp --dport 53 -j REDIRECT --to-ports 5300 2>/dev/null

# Guardar iptables
mkdir -p /etc/iptables
iptables-save > /etc/iptables/rules.v4 2>/dev/null

if [[ -x /usr/local/bin/dnstt-server ]]; then
  systemctl daemon-reload
  systemctl enable slowdns &>/dev/null
  systemctl restart slowdns &>/dev/null
  echo -e "${GREEN}[✓] SlowDNS instalado${NC}"
else
  echo -e "${YELLOW}[!] Binario dnstt-server no disponible. Config generada.${NC}"
  echo -e "    Instala manualmente dnstt-server en /usr/local/bin/"
fi

IP=$(curl -s --max-time 3 ipv4.icanhazip.com 2>/dev/null || hostname -I | awk '{print $1}')
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  Nameserver:  ${YELLOW}${NS_DOMAIN}${NC}"
echo -e "  Public Key:  ${YELLOW}${PUBKEY}${NC}"
echo -e "  Server IP:   ${YELLOW}${IP}${NC}"
echo -e "  Buffer Ext:  ${YELLOW}512${NC}"
echo -e "  Buffer Int:  ${YELLOW}1800${NC}"
echo -e "  UDP Port:    ${YELLOW}5300${NC} (redir 53)"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${YELLOW}  Configura un NS record: ${NS_DOMAIN} → ${IP}${NC}"
echo "${NS_DOMAIN}|${PUBKEY}|${IP}" > $DIR/db/slowdns.conf
