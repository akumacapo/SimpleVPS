#!/bin/bash
# SimpleVPS - Limitador de conexiones
DB="/etc/SimpleVPS/db/users.db"
LOG="/etc/SimpleVPS/tmp/limitador.log"
while true; do
  if [[ -f $DB ]]; then
    while IFS='|' read -r user pass expira limite creado; do
      [[ -z $user ]] && continue
      conexiones=$(ps aux 2>/dev/null | grep -E "sshd: ${user}@|dropbear.*${user}" | grep -v grep | wc -l)
      if [[ $conexiones -gt $limite ]]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') - $user excedio limite ($conexiones/$limite)" >> $LOG
        ps aux 2>/dev/null | grep -E "sshd: ${user}@" | grep -v grep | awk '{print $2}' | tail -n +$((limite+1)) | xargs -r kill -9 2>/dev/null
      fi
      hoy=$(date +%Y-%m-%d)
      if [[ "$expira" < "$hoy" ]]; then
        pkill -u "$user" 2>/dev/null
        passwd -l "$user" 2>/dev/null
      fi
    done < $DB
  fi
  sleep 30
done
