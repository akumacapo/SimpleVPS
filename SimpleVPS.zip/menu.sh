#!/bin/bash
# SimpleVPS Manager v5.0 - Panel de Control completo
# Compatible BotGen | Zero-Lag /proc | Telegram | Nginx | Auto-Kill

DIR="/etc/SimpleVPS"
DB="${DIR}/db/users.db"
XDB="${DIR}/db/xray_users.db"
CFG="${DIR}/db/config"
BANNER_FILE="${DIR}/db/banner.txt"
DOMAIN_FILE="${DIR}/db/domain.txt"
TG_CFG="${DIR}/db/telegram.conf"

RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'
BLUE='\033[1;36m'; WHITE='\033[1;37m'; NC='\033[0m'

source ${DIR}/lib/funcoes.sh 2>/dev/null || true

# ═══════════ DASHBOARD ═══════════
show_dashboard(){
  clear
  local ip domain os uptime_s cpu ram_u ram_t ram_f disk_t disk_u disk_f disk_p
  ip=$(get_ip)
  domain=$(cat $DOMAIN_FILE 2>/dev/null || echo "-")
  os=$(grep PRETTY /etc/os-release 2>/dev/null | cut -d'"' -f2)
  uptime_s=$(uptime -p 2>/dev/null | sed 's/up //')
  cpu=$(cpu_usage 2>/dev/null || echo "0.0")
  read ram_u ram_t ram_f <<< "$(ram_info 2>/dev/null || echo "0 0 0")"
  read disk_t disk_u disk_f disk_p <<< "$(disk_info 2>/dev/null || echo "0 0 0 0%")"
  local cpu_int=${cpu%.*}
  local ram_pct=0
  [[ $ram_t -gt 0 ]] && ram_pct=$((ram_u * 100 / ram_t))

  local ssh_c=$(count_lines $DB)
  local xray_c=$(count_lines $XDB)
  local vm=0 vl=0 tr=0
  # Contar por tipo si hay tags (simplificado)
  vl=$xray_c

  local on_ssh=$(who 2>/dev/null | wc -l)

  echo -e "${BLUE}┌──────────────────────────────────────────────┐${NC}"
  echo -e "${BLUE}│${NC}     ${YELLOW}🛰️  PANEL DE CONTROL VPS  🛰️${NC}           ${BLUE}│${NC}"
  echo -e "${BLUE}└──────────────────────────────────────────────┘${NC}"
  echo -e " ${WHITE}OS${NC}     : $os"
  echo -e " ${WHITE}UPTIME${NC} : $uptime_s"
  echo -e " ${WHITE}IP/DOM${NC} : $ip / $domain"
  echo -e " ${WHITE}DISCO${NC}  : Total ${disk_t}G  Uso ${disk_u}G  Libre ${disk_f}G"
  echo -e " ${WHITE}CPU${NC}    : $(bar_graph ${cpu_int} 20)  Cores: $(nproc)"
  echo -e " ${WHITE}RAM${NC}    : $(bar_graph ${ram_pct} 20)  ${ram_u}M/${ram_t}M  Libre: ${ram_f}M"
  echo -e "${BLUE}────────────────────────────────────────────────${NC}"
  echo -ne " ${WHITE}SERVICIOS:${NC} "
  echo -ne "XRAY:[$(svc_on xray)] "
  echo -ne "NGINX:[$(svc_on nginx)] "
  echo -ne "SSH:[$(svc_on sshd 2>/dev/null||svc_on ssh)] "
  echo -ne "DROP:[$(svc_on dropbear)]"
  echo ""
  echo -ne "          "
  echo -ne "HYST:[$(svc_on hysteria)] "
  echo -ne "BADVPN:[$(svc_on badvpn)] "
  echo -ne "WS:[$(svc_on wsproxy)]"
  echo ""
  echo -e "${BLUE}────────────────────────────────────────────────${NC}"
  echo -e " ${WHITE}CUENTAS${NC} : SSH:${YELLOW}$ssh_c${NC}  Xray:${YELLOW}$xray_c${NC}"
  echo -e " ${WHITE}ESTADO${NC}  : ON SSH:${GREEN}$on_ssh${NC}"
  echo -e "${BLUE}────────────────────────────────────────────────${NC}"
}

menu(){
  show_dashboard
  echo -e " ${GREEN}[01]${NC} SSH & Usuarios     ${GREEN}[06]${NC} Telegram Notify"
  echo -e " ${GREEN}[02]${NC} Protocolos         ${GREEN}[07]${NC} Generador Payloads"
  echo -e " ${GREEN}[03]${NC} Xray (VM/VL/TR)    ${GREEN}[08]${NC} Menu Extras"
  echo -e " ${GREEN}[04]${NC} Monitor Tiempo Real${GREEN}[09]${NC} Reboot VPS"
  echo -e " ${GREEN}[05]${NC} Nginx Gateway      ${GREEN}[10]${NC} Ajustes Sistema"
  echo -e " ${RED}[x]${NC}  Salir"
  echo -e "${BLUE}────────────────────────────────────────────────${NC}"
  echo -e "          ${WHITE}VERSIÓN SCRIPT: V5.0 LTS${NC}"
  echo -e "${BLUE}────────────────────────────────────────────────${NC}"
  echo -ne "  Opcion: "; read op
  case $op in
    1|01) menu_usuarios ;;
    2|02) menu_protocolos ;;
    3|03) menu_xray_panel ;;
    4|04) bash ${DIR}/bin/monitor.sh; menu ;;
    5|05) bash ${DIR}/bin/inst_nginx.sh; pause; menu ;;
    6|06) menu_telegram ;;
    7|07) bash ${DIR}/bin/payloads.sh; menu ;;
    8|08) menu_extras ;;
    9|09) echo -ne "  ${RED}¿Reiniciar? (s/n): ${NC}"; read c; [[ $c = @(s|S) ]] && { tg_send "🔄 Reboot VPS"; reboot; } ;;
    10) menu_ajustes ;;
    x|X|0) clear; exit 0 ;;
    *) menu ;;
  esac
}
pause(){ echo -ne "\n  ${WHITE}Enter...${NC}"; read; }

# ═══════════ USUARIOS SSH ═══════════
menu_usuarios(){
  show_dashboard
  echo -e " ${YELLOW}══ SSH & USUARIOS ══${NC}"
  echo -e " ${GREEN}[1]${NC} Crear SSH   ${GREEN}[2]${NC} Eliminar   ${GREEN}[3]${NC} Listar"
  echo -e " ${GREEN}[4]${NC} Renovar     ${GREEN}[5]${NC} Bloquear   ${GREEN}[6]${NC} Detalle"
  echo -e " ${GREEN}[7]${NC} Cambiar pass${GREEN}[8]${NC} Crear Xray ${GREEN}[9]${NC} Listar Xray"
  echo -e " ${RED}[0]${NC} Volver"
  echo -ne "  Opcion: "; read op
  case $op in
    1) crear_ssh ;; 2) eliminar_ssh ;; 3) listar_ssh ;;
    4) renovar_ssh ;; 5) bloqueo_ssh ;; 6) detalle_ssh ;;
    7) cambiar_pass ;; 8) crear_xray ;; 9) listar_xray ;;
    0) menu ;; *) menu_usuarios ;;
  esac
}

crear_ssh(){
  echo -ne "  Usuario: "; read user
  [[ -z $user ]] && { menu_usuarios; return; }
  id "$user" &>/dev/null && { echo -e "${RED}Existe${NC}"; sleep 1; menu_usuarios; return; }
  echo -ne "  Pass (Enter=rand): "; read pass
  [[ -z $pass ]] && pass=$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 8)
  echo -ne "  Dias [30]: "; read dias; [[ -z $dias || ! $dias =~ ^[0-9]+$ ]] && dias=30
  echo -ne "  Limite [1]: "; read limite; [[ -z $limite || ! $limite =~ ^[0-9]+$ ]] && limite=1
  useradd -M -s /bin/false "$user" 2>/dev/null
  (echo "$pass"; echo "$pass") | passwd "$user" &>/dev/null
  expira=$(date -d "+${dias} days" +"%Y-%m-%d")
  chage -E "$expira" "$user" 2>/dev/null
  echo "${user}|${pass}|${expira}|${limite}|$(date +%Y-%m-%d)|active" >> $DB
  echo -e "${GREEN}[✓] $user | $pass | $expira | lim:$limite${NC}"
  tg_send "➕ <b>Usuario SSH creado</b>%0A<code>$user</code> | $dias dias | lim $limite"
  pause; menu_usuarios
}

eliminar_ssh(){
  [[ ! -s $DB ]] && { echo -e "${RED}Vacio${NC}"; sleep 1; menu_usuarios; return; }
  n=1; while IFS='|' read -r u p e l c s; do echo -e "  ${GREEN}[$n]${NC} $u"; let n++; done < $DB
  echo -ne "  Num: "; read num; [[ -z $num || $num -eq 0 ]] && { menu_usuarios; return; }
  user=$(sed -n "${num}p" $DB | cut -d'|' -f1)
  pkill -u "$user" 2>/dev/null; userdel -r "$user" 2>/dev/null
  sed -i "/^${user}:/d" /etc/passwd /etc/shadow 2>/dev/null
  sed -i "${num}d" $DB
  tg_send "❌ <b>Usuario eliminado</b>%0A<code>$user</code>"
  echo -e "${GREEN}[✓] $user eliminado${NC}"; sleep 1; menu_usuarios
}

listar_ssh(){
  echo ""; printf "  %-12s %-10s %-11s %-5s %-4s %s\n" "USER" "PASS" "EXPIRA" "DIAS" "LIM" "EST"
  echo -e "  ${BLUE}────────────────────────────────────────${NC}"
  while IFS='|' read -r u p e l c s; do
    d=$(dias_restantes "$e")
    [[ $d -lt 0 ]] && dc="${RED}$d${NC}" || dc="${GREEN}$d${NC}"
    [[ "$s" == "blocked" ]] && st="${RED}BLK${NC}" || st="${GREEN}OK${NC}"
    [[ $d -lt 0 ]] && st="${RED}EXP${NC}"
    printf "  %-12s %-10s %-11s " "$u" "$p" "$e"
    echo -ne "$dc"; printf "   %-4s " "$l"; echo -e "$st"
  done < $DB
  pause; menu_usuarios
}

renovar_ssh(){
  n=1; while IFS='|' read -r u p e l c s; do echo -e "  ${GREEN}[$n]${NC} $u ($e)"; let n++; done < $DB
  echo -ne "  Num: "; read num; [[ -z $num ]] && { menu_usuarios; return; }
  linea=$(sed -n "${num}p" $DB)
  user=$(echo "$linea"|cut -d'|' -f1); pass=$(echo "$linea"|cut -d'|' -f2)
  limite=$(echo "$linea"|cut -d'|' -f4); creado=$(echo "$linea"|cut -d'|' -f5)
  echo -ne "  Dias [30]: "; read dias; [[ -z $dias || ! $dias =~ ^[0-9]+$ ]] && dias=30
  nueva=$(date -d "+${dias} days" +"%Y-%m-%d")
  chage -E "$nueva" "$user" 2>/dev/null; passwd -u "$user" 2>/dev/null
  sed -i "${num}c\\${user}|${pass}|${nueva}|${limite}|${creado}|active" $DB
  tg_send "🔄 <b>Renovado</b> <code>$user</code> → $nueva"
  echo -e "${GREEN}[✓] $user → $nueva${NC}"; sleep 1; menu_usuarios
}

bloqueo_ssh(){
  n=1; while IFS='|' read -r u p e l c s; do
    [[ "$s" == "blocked" ]] && st="${RED}BLK${NC}" || st="${GREEN}ON${NC}"
    echo -e "  ${GREEN}[$n]${NC} $u [$st]"; let n++
  done < $DB
  echo -ne "  Num: "; read num; [[ -z $num ]] && { menu_usuarios; return; }
  linea=$(sed -n "${num}p" $DB)
  user=$(echo "$linea"|cut -d'|' -f1); pass=$(echo "$linea"|cut -d'|' -f2)
  expira=$(echo "$linea"|cut -d'|' -f3); limite=$(echo "$linea"|cut -d'|' -f4)
  creado=$(echo "$linea"|cut -d'|' -f5); status=$(echo "$linea"|cut -d'|' -f6)
  if [[ "$status" == "blocked" ]]; then
    passwd -u "$user" 2>/dev/null
    sed -i "${num}c\\${user}|${pass}|${expira}|${limite}|${creado}|active" $DB
    tg_send "🔓 <b>Desbloqueado</b> <code>$user</code>"
    echo -e "${GREEN}Desbloqueado${NC}"
  else
    pkill -u "$user" 2>/dev/null; passwd -l "$user" 2>/dev/null
    sed -i "${num}c\\${user}|${pass}|${expira}|${limite}|${creado}|blocked" $DB
    tg_send "🔒 <b>Bloqueado</b> <code>$user</code>"
    echo -e "${RED}Bloqueado${NC}"
  fi
  sleep 1; menu_usuarios
}

detalle_ssh(){
  echo -ne "  Usuario: "; read user
  linea=$(grep "^${user}|" $DB)
  [[ -z $linea ]] && { echo -e "${RED}No encontrado${NC}"; sleep 1; menu_usuarios; return; }
  echo -e "  Pass: ${YELLOW}$(echo $linea|cut -d'|' -f2)${NC}"
  echo -e "  Expira: $(echo $linea|cut -d'|' -f3)  Dias: $(dias_restantes $(echo $linea|cut -d'|' -f3))"
  echo -e "  Limite: $(echo $linea|cut -d'|' -f4)  Estado: $(echo $linea|cut -d'|' -f6)"
  pause; menu_usuarios
}

cambiar_pass(){
  n=1; while IFS='|' read -r u p e l c s; do echo -e "  ${GREEN}[$n]${NC} $u"; let n++; done < $DB
  echo -ne "  Num: "; read num; echo -ne "  Nueva pass: "; read pass
  [[ -z $num || -z $pass ]] && { menu_usuarios; return; }
  linea=$(sed -n "${num}p" $DB)
  user=$(echo "$linea"|cut -d'|' -f1)
  (echo "$pass"; echo "$pass") | passwd "$user" &>/dev/null
  sed -i "${num}c\\${user}|${pass}|$(echo $linea|cut -d'|' -f3)|$(echo $linea|cut -d'|' -f4)|$(echo $linea|cut -d'|' -f5)|$(echo $linea|cut -d'|' -f6)" $DB
  echo -e "${GREEN}[✓] Pass actualizado${NC}"; sleep 1; menu_usuarios
}

crear_xray(){
  echo -ne "  Nombre: "; read nombre; [[ -z $nombre ]] && { menu_usuarios; return; }
  UUID=$(cat /proc/sys/kernel/random/uuid 2>/dev/null || python3 -c "import uuid;print(uuid.uuid4())")
  echo -ne "  Dias [30]: "; read dias; [[ -z $dias || ! $dias =~ ^[0-9]+$ ]] && dias=30
  expira=$(date -d "+${dias} days" +"%Y-%m-%d")
  echo "${nombre}|${UUID}|${expira}|$(date +%Y-%m-%d)|active" >> $XDB
  echo -e "${GREEN}[✓] $nombre${NC}\n  UUID: ${YELLOW}$UUID${NC}\n  Expira: $expira"
  tg_send "➕ <b>Xray user</b> $nombre%0A<code>$UUID</code>"
  pause; menu_usuarios
}

listar_xray(){
  echo ""; printf "  %-12s %-36s %-11s %s\n" "NOMBRE" "UUID" "EXPIRA" "DIAS"
  while IFS='|' read -r n u e c s; do
    printf "  %-12s %-36s %-11s %s\n" "$n" "$u" "$e" "$(dias_restantes $e)"
  done < $XDB
  [[ -f $DIR/db/xray.uuid ]] && echo -e "\n  Master: ${YELLOW}$(cat $DIR/db/xray.uuid)${NC}"
  pause; menu_usuarios
}

# ═══════════ PROTOCOLOS ═══════════
menu_protocolos(){
  show_dashboard
  echo -e " ${YELLOW}══ PROTOCOLOS ══${NC}"
  echo -e " ${GREEN}[1]${NC} OpenSSH puerto   ${GREEN}[2]${NC} Dropbear"
  echo -e " ${GREEN}[3]${NC} Stunnel SSL      ${GREEN}[4]${NC} BadVPN 7300"
  echo -e " ${GREEN}[5]${NC} Hysteria v1      ${GREEN}[6]${NC} Xray Core"
  echo -e " ${GREEN}[7]${NC} SlowDNS          ${GREEN}[8]${NC} WS Proxy"
  echo -e " ${GREEN}[9]${NC} Ver puertos      ${RED}[0]${NC} Volver"
  echo -ne "  Opcion: "; read op
  case $op in
    1) echo -ne "  Puerto: "; read p; sed -i "s/^#\?Port .*/Port $p/" /etc/ssh/sshd_config; systemctl restart sshd 2>/dev/null; echo -e "${GREEN}OK${NC}"; sleep 1 ;;
    2) apt-get install -y dropbear &>/dev/null; echo -ne "  Puerto [443]: "; read p; [[ -z $p ]] && p=443
       printf 'NO_START=0\nDROPBEAR_PORT=%s\nDROPBEAR_EXTRA_ARGS="-p %s"\nDROPBEAR_BANNER="%s"\n' "$p" "$p" "$BANNER_FILE" > /etc/default/dropbear
       systemctl enable --now dropbear &>/dev/null; echo -e "${GREEN}Dropbear :$p${NC}"; sleep 1 ;;
    3) apt-get install -y stunnel4 &>/dev/null; echo -ne "  SSL [445]: "; read ps; [[ -z $ps ]] && ps=445
       echo -ne "  Dest [22]: "; read pd; [[ -z $pd ]] && pd=22
       mkdir -p /etc/stunnel; [[ ! -f /etc/stunnel/stunnel.pem ]] && openssl req -new -x509 -days 3650 -nodes -out /etc/stunnel/stunnel.pem -keyout /etc/stunnel/stunnel.pem -subj "/CN=s" 2>/dev/null
       printf "cert=/etc/stunnel/stunnel.pem\npid=/var/run/stunnel.pid\n[ssh]\naccept=%s\nconnect=127.0.0.1:%s\n" "$ps" "$pd" > /etc/stunnel/stunnel.conf
       sed -i 's/ENABLED=0/ENABLED=1/' /etc/default/stunnel4 2>/dev/null; systemctl restart stunnel4 2>/dev/null; echo -e "${GREEN}Stunnel $ps→$pd${NC}"; sleep 1 ;;
    4) if ! command -v badvpn-udpgw &>/dev/null; then
         apt-get install -y cmake build-essential &>/dev/null; cd /tmp
         wget -q https://github.com/ambrop72/badvpn/archive/refs/tags/1.999.130.tar.gz -O b.tgz 2>/dev/null
         tar xzf b.tgz; cd badvpn-1.999.130; mkdir build; cd build
         cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 &>/dev/null; make -j$(nproc) &>/dev/null
         cp udpgw/badvpn-udpgw /usr/bin/; cd /; rm -rf /tmp/badvpn* /tmp/b.tgz
       fi
       cat > /etc/systemd/system/badvpn.service << 'E'
[Unit]
Description=BadVPN
After=network.target
[Service]
ExecStart=/usr/bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 2000 --max-connections-for-client 30
Restart=always
[Install]
WantedBy=multi-user.target
E
       systemctl daemon-reload; systemctl enable --now badvpn &>/dev/null; echo -e "${GREEN}BadVPN :7300${NC}"; sleep 1 ;;
    5) bash ${DIR}/bin/inst_hysteria.sh; pause ;;
    6) bash ${DIR}/bin/inst_xray.sh; pause ;;
    7) bash ${DIR}/bin/inst_slowdns.sh; pause ;;
    8) bash ${DIR}/bin/inst_wsproxy.sh; pause ;;
    9) ss -tulnp 2>/dev/null | grep -E 'LISTEN|UNCONN' | awk '{print $1,$5,$7}'; pause ;;
    0) menu; return ;;
  esac
  menu_protocolos
}

menu_xray_panel(){
  show_dashboard
  echo -e " ${YELLOW}══ XRAY PANEL ══${NC}"
  [[ -f $DIR/db/xray.uuid ]] && echo -e " UUID Master: ${YELLOW}$(cat $DIR/db/xray.uuid)${NC}"
  echo -e " ${GREEN}[1]${NC} Instalar/Reinstalar Xray"
  echo -e " ${GREEN}[2]${NC} Crear usuario Xray"
  echo -e " ${GREEN}[3]${NC} Listar usuarios Xray"
  echo -e " ${GREEN}[4]${NC} Eliminar usuario Xray"
  echo -e " ${GREEN}[5]${NC} Reiniciar Xray"
  echo -e " ${RED}[0]${NC} Volver"
  echo -ne "  Opcion: "; read op
  case $op in
    1) bash ${DIR}/bin/inst_xray.sh; pause ;;
    2) crear_xray; return ;;
    3) listar_xray; return ;;
    4)
      n=1; while IFS='|' read -r n_ u e c s; do echo -e "  [$n] $n_"; let n++; done < $XDB
      echo -ne "  Num: "; read num; [[ -n $num ]] && sed -i "${num}d" $XDB && echo -e "${GREEN}OK${NC}"
      sleep 1 ;;
    5) systemctl restart xray; echo -e "${GREEN}Xray reiniciado${NC}"; sleep 1 ;;
    0) menu; return ;;
  esac
  menu_xray_panel
}

# ═══════════ TELEGRAM ═══════════
menu_telegram(){
  show_dashboard
  echo -e " ${YELLOW}══ TELEGRAM NOTIFY ══${NC}"
  if [[ -f $TG_CFG ]]; then
    source $TG_CFG 2>/dev/null
    echo -e "  Token: ${TG_TOKEN:0:12}..."
    echo -e "  Chat:  $TG_CHAT"
  else
    echo -e "  ${RED}No configurado${NC}"
  fi
  echo ""
  echo -e " ${GREEN}[1]${NC} Configurar Token + Chat ID"
  echo -e " ${GREEN}[2]${NC} Probar notificacion"
  echo -e " ${GREEN}[3]${NC} Activar watcher de logins"
  echo -e " ${GREEN}[4]${NC} Desactivar watcher"
  echo -e " ${GREEN}[5]${NC} Enviar estado del sistema"
  echo -e " ${RED}[0]${NC} Volver"
  echo -ne "  Opcion: "; read op
  case $op in
    1)
      echo -ne "  Bot Token: "; read token
      echo -ne "  Chat ID: "; read chat
      echo -e "TG_TOKEN=\"$token\"\nTG_CHAT=\"$chat\"" > $TG_CFG
      echo -e "${GREEN}[✓] Guardado${NC}"; sleep 1 ;;
    2)
      tg_send "✅ <b>SimpleVPS</b>%0ANotificaciones activas%0A$(date '+%F %T')"
      echo -e "${GREEN}Enviado${NC}"; sleep 1 ;;
    3)
      pkill -f tg_login_watch 2>/dev/null
      nohup ${DIR}/bin/tg_login_watch.sh >> ${DIR}/tmp/tg.log 2>&1 &
      (crontab -l 2>/dev/null | grep -v tg_login; echo "@reboot ${DIR}/bin/tg_login_watch.sh >> ${DIR}/tmp/tg.log 2>&1") | crontab -
      echo -e "${GREEN}[✓] Watcher activo${NC}"; sleep 1 ;;
    4)
      pkill -f tg_login_watch 2>/dev/null
      crontab -l 2>/dev/null | grep -v tg_login | crontab -
      echo -e "${GREEN}Desactivado${NC}"; sleep 1 ;;
    5)
      ip=$(get_ip); cpu=$(cpu_usage); read ru rt rf <<< "$(ram_info)"
      tg_send "📊 <b>Estado VPS</b>%0AIP: $ip%0ACPU: ${cpu}%0ARAM: ${ru}M/${rt}M%0AUptime: $(uptime -p)"
      echo -e "${GREEN}Enviado${NC}"; sleep 1 ;;
    0) menu; return ;;
  esac
  menu_telegram
}

# ═══════════ EXTRAS ═══════════
menu_extras(){
  show_dashboard
  echo -e " ${YELLOW}══ MENU EXTRAS ══${NC}"
  echo -e " ${GREEN}[1]${NC} Banner SSH (HTML)"
  echo -e " ${GREEN}[2]${NC} Backup / Restore"
  echo -e " ${GREEN}[3]${NC} Limitador / Auto-Kill"
  echo -e " ${GREEN}[4]${NC} Info protocolos"
  echo -e " ${GREEN}[5]${NC} Cambiar dominio"
  echo -e " ${RED}[0]${NC} Volver"
  echo -ne "  Opcion: "; read op
  case $op in
    1) menu_banner ;;
    2) menu_backup ;;
    3) menu_limitador ;;
    4)
      ip=$(get_ip)
      echo -e " IP: $ip"
      [[ -f $DIR/db/xray.uuid ]] && echo -e " Xray UUID: $(cat $DIR/db/xray.uuid)"
      [[ -f $DIR/db/hysteria.conf ]] && echo -e " Hysteria: $(cat $DIR/db/hysteria.conf)"
      [[ -f $DIR/db/slowdns.conf ]] && echo -e " SlowDNS: $(cat $DIR/db/slowdns.conf)"
      [[ -f $DIR/db/wsproxy.conf ]] && echo -e " WS: $(cat $DIR/db/wsproxy.conf)"
      pause ;;
    5)
      echo -ne "  Dominio: "; read d
      echo "$d" > $DOMAIN_FILE
      echo -e "${GREEN}Dominio: $d${NC}"; sleep 1 ;;
    0) menu; return ;;
  esac
  menu_extras
}

menu_banner(){
  echo -e " ${GREEN}[1]${NC} Editar  ${GREEN}[2]${NC} Default  ${GREEN}[3]${NC} HTML  ${GREEN}[4]${NC} Aplicar SSH"
  echo -ne "  Op: "; read op
  case $op in
    1) echo "Ctrl+D termina:"; cat > $BANNER_FILE ;;
    2) echo -e "═══════════════════════════════════\n   Bienvenido a SimpleVPS\n═══════════════════════════════════" > $BANNER_FILE ;;
    3) cat > $BANNER_FILE << 'B'
<!DOCTYPE html><html><body style="background:#0a0a0a;color:#00ff88;font-family:monospace;text-align:center;padding:20px">
<h2>SimpleVPS</h2><p>Acceso autorizado</p></body></html>
B
       ;;
    4)
      grep -q "^Banner" /etc/ssh/sshd_config && sed -i "s|^Banner.*|Banner $BANNER_FILE|" /etc/ssh/sshd_config || echo "Banner $BANNER_FILE" >> /etc/ssh/sshd_config
      systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null
      echo -e "${GREEN}Aplicado${NC}" ;;
  esac
  sleep 1; menu_extras
}

menu_backup(){
  echo -e " ${GREEN}[1]${NC} Crear backup  ${GREEN}[2]${NC} Restaurar  ${GREEN}[3]${NC} Listar"
  echo -ne "  Op: "; read op
  case $op in
    1)
      mkdir -p ${DIR}/backup
      f=${DIR}/backup/full_$(date +%Y%m%d_%H%M%S).tar.gz
      tar czf $f -C $DIR db 2>/dev/null
      echo -e "${GREEN}$f${NC}" ;;
    2)
      ls -1 ${DIR}/backup/*.tar.gz 2>/dev/null | nl
      echo -ne "  Num: "; read n
      a=$(ls -1 ${DIR}/backup/*.tar.gz 2>/dev/null | sed -n "${n}p")
      [[ -f $a ]] && tar xzf $a -C $DIR && echo -e "${GREEN}OK${NC}" || echo -e "${RED}Fail${NC}" ;;
    3) ls -lh ${DIR}/backup/ 2>/dev/null; pause ;;
  esac
  sleep 1; menu_extras
}

menu_limitador(){
  echo -e " Auto-Kill: $(pgrep -f autokill.sh &>/dev/null && echo -e "${GREEN}ON${NC}" || echo -e "${RED}OFF${NC}")"
  echo -e " ${GREEN}[1]${NC} Iniciar Auto-Kill  ${GREEN}[2]${NC} Detener  ${GREEN}[3]${NC} Logs"
  echo -ne "  Op: "; read op
  case $op in
    1)
      pkill -f autokill.sh 2>/dev/null; pkill -f limitador.sh 2>/dev/null
      nohup ${DIR}/bin/autokill.sh >> ${DIR}/tmp/autokill.log 2>&1 &
      (crontab -l 2>/dev/null | grep -v autokill; echo "@reboot ${DIR}/bin/autokill.sh >> ${DIR}/tmp/autokill.log 2>&1") | crontab -
      echo -e "${GREEN}Auto-Kill iniciado${NC}" ;;
    2) pkill -f autokill.sh 2>/dev/null; crontab -l 2>/dev/null | grep -v autokill | crontab -; echo -e "${GREEN}Detenido${NC}" ;;
    3) tail -20 ${DIR}/tmp/autokill.log 2>/dev/null || echo "Sin logs"; pause ;;
  esac
  sleep 1; menu_extras
}

# ═══════════ AJUSTES SISTEMA ═══════════
menu_ajustes(){
  show_dashboard
  echo -e " ${YELLOW}AJUSTES Y FUNCIONES DEL SISTEMA${NC}"
  echo -e "${BLUE}════════════════════════════════════════════════════${NC}"
  echo -e " ${GREEN}[1]${NC}  Verificar Sistema en Ejecucion"
  echo -e " ${GREEN}[2]${NC}  Optimizar Red (BBR/FQ/Sysctl)"
  echo -e " ${GREEN}[3]${NC}  Limpieza Profunda de Disco"
  echo -e " ${GREEN}[4]${NC}  Backup/Restaurar Servidor"
  echo -e " ${GREEN}[5]${NC}  Informacion de Puertos"
  echo -e " ${GREEN}[6]${NC}  Reiniciar Todos los Servicios"
  echo -e " ${GREEN}[7]${NC}  Cambiar Dominio del Servidor"
  echo -e " ${GREEN}[8]${NC}  Instalar SlowDNS"
  echo -e " ${GREEN}[9]${NC}  Actualizar Dropbear"
  echo -e " ${GREEN}[10]${NC} Optimizar Memoria RAM"
  echo -e " ${GREEN}[11]${NC} Speedtest"
  echo -e " ${GREEN}[12]${NC} Actualizar Xray Core"
  echo -e " ${GREEN}[13]${NC} Limpiador cuentas expiradas"
  echo -e " ${GREEN}[14]${NC} Configurar Auto Reinicio"
  echo -e " ${GREEN}[15]${NC} Reiniciar Servidor (Reboot)"
  echo -e " ${GREEN}[16]${NC} Desinstalar Script"
  echo -e " ${RED}[0]${NC}  Volver"
  echo -e "${BLUE}════════════════════════════════════════════════════${NC}"
  echo -ne "  Opcion: "; read op
  case $op in
    1)
      echo -e "\n ${WHITE}Procesos clave:${NC}"
      for s in xray nginx sshd dropbear hysteria badvpn wsproxy slowdns; do
        echo -ne "  $s: "; svc_on $s; echo
      done
      echo -e " Auto-Kill: $(pgrep -f autokill &>/dev/null && echo ON || echo OFF)"
      echo -e " TG Watch:  $(pgrep -f tg_login &>/dev/null && echo ON || echo OFF)"
      pause ;;
    2) bash ${DIR}/bin/sysctl_bbr.sh; pause ;;
    3)
      echo -e "${YELLOW}[*] Limpieza profunda...${NC}"
      apt-get autoremove -y &>/dev/null; apt-get clean &>/dev/null
      journalctl --vacuum-size=50M &>/dev/null
      rm -rf /tmp/* /var/tmp/* 2>/dev/null
      sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
      echo -e "${GREEN}[✓] Disco limpiado${NC}"; df -h /; pause ;;
    4) menu_backup; return ;;
    5) ss -tulnp 2>/dev/null | grep -E 'LISTEN|UNCONN'; pause ;;
    6)
      for s in xray nginx sshd dropbear hysteria badvpn wsproxy slowdns stunnel4; do
        systemctl restart $s 2>/dev/null && echo -e "  $s ${GREEN}OK${NC}" || true
      done
      tg_send "🔁 Servicios reiniciados"
      pause ;;
    7) echo -ne "  Dominio: "; read d; echo "$d" > $DOMAIN_FILE; echo -e "${GREEN}$d${NC}"; sleep 1 ;;
    8) bash ${DIR}/bin/inst_slowdns.sh; pause ;;
    9) apt-get install --reinstall -y dropbear &>/dev/null; systemctl restart dropbear; echo -e "${GREEN}Dropbear actualizado${NC}"; sleep 1 ;;
    10)
      sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
      echo -e "${GREEN}RAM optimizada${NC}"; free -h; pause ;;
    11)
      command -v speedtest-cli &>/dev/null || apt-get install -y speedtest-cli &>/dev/null
      speedtest-cli --simple 2>/dev/null || echo "No disponible"
      pause ;;
    12) bash ${DIR}/bin/inst_xray.sh; pause ;;
    13)
      bash ${DIR}/bin/cleaner.sh
      (crontab -l 2>/dev/null | grep -v cleaner; echo "0 4 * * * ${DIR}/bin/cleaner.sh") | crontab -
      echo -e "${GREEN}Limpieza + cron 04:00${NC}"; pause ;;
    14)
      echo -e " [1] Diario 03:00  [2] Semanal Dom  [3] Off"
      echo -ne "  Op: "; read a
      case $a in
        1) (crontab -l 2>/dev/null|grep -v reboot; echo "0 3 * * * /sbin/reboot")|crontab -; echo -e "${GREEN}Diario${NC}" ;;
        2) (crontab -l 2>/dev/null|grep -v reboot; echo "0 3 * * 0 /sbin/reboot")|crontab -; echo -e "${GREEN}Semanal${NC}" ;;
        3) crontab -l 2>/dev/null|grep -v reboot|crontab -; echo -e "${GREEN}Off${NC}" ;;
      esac
      sleep 1 ;;
    15) echo -ne "  ${RED}¿Reboot? (s/n): ${NC}"; read c; [[ $c = @(s|S) ]] && reboot ;;
    16)
      echo -ne "  ${RED}¿Desinstalar SimpleVPS? (escribe SI): ${NC}"; read c
      if [[ "$c" == "SI" ]]; then
        pkill -f autokill 2>/dev/null; pkill -f tg_login 2>/dev/null; pkill -f limitador 2>/dev/null
        systemctl disable --now xray hysteria badvpn wsproxy slowdns 2>/dev/null
        rm -rf /etc/SimpleVPS /usr/bin/simplevps /usr/bin/svp
        crontab -l 2>/dev/null | grep -v SimpleVPS | grep -v autokill | grep -v cleaner | grep -v tg_login | crontab -
        echo -e "${GREEN}Desinstalado${NC}"; exit 0
      fi ;;
    0) menu; return ;;
  esac
  menu_ajustes
}

# ═══════════ INICIO ═══════════
mkdir -p ${DIR}/{bin,lib,db,tmp,backup}
[[ ! -f $DB ]] && touch $DB
[[ ! -f $XDB ]] && touch $XDB
[[ ! -f $BANNER_FILE ]] && echo "SimpleVPS - Acceso autorizado" > $BANNER_FILE
menu
