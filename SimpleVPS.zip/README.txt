SimpleVPS Manager v5.0 LTS
==========================
Panel de Control VPS compatible con BotGen.

INSTALACION: chmod +x install.sh && ./install.sh
COMANDOS:    simplevps | svp

CARACTERISTICAS PRINCIPALES
  * Interfaz Zero-Lag: lectura directa /proc
  * Auto-Kill inteligente: anti multi-login padre/hijo
  * Notificaciones Telegram: logins, bloqueos, estado
  * Nginx Gateway: gestion puertos 80 y 443
  * Optimizacion de Red: BBR + Sysctl automatico
  * Backup & Restore: usuarios y configuraciones

PANEL PRINCIPAL
  [01] SSH & Usuarios      [06] Telegram Notify
  [02] Protocolos          [07] Generador Payloads
  [03] Xray (VM/VL/TR)     [08] Menu Extras
  [04] Monitor Tiempo Real [09] Reboot VPS
  [05] Nginx Gateway       [10] Ajustes Sistema

PROTOCOLOS
  SSH / Dropbear / OpenSSH / Stunnel
  Hysteria v1 (UDP 36712 + obfs)
  Xray: VMess VLESS Trojan WS gRPC
  BadVPN 7300 | SlowDNS | WS Proxy | Nginx

AJUSTES SISTEMA (16 opciones)
  Verificar · BBR · Limpieza disco · Backup
  Puertos · Reiniciar servicios · Dominio
  SlowDNS · Dropbear · RAM · Speedtest
  Xray update · Limpiador · Auto-Reboot
  Reboot · Desinstalar

ARCHIVOS
  menu.sh install.sh
  bin/autokill.sh monitor.sh payloads.sh cleaner.sh
  bin/inst_*.sh sysctl_bbr.sh tg_login_watch.sh
  lib/funcoes.sh
