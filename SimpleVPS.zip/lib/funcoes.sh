#!/bin/bash
# SimpleVPS - Funciones auxiliares v5

RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'
BLUE='\033[1;36m'; WHITE='\033[1;37m'; NC='\033[0m'

get_ip(){ curl -s --max-time 3 ipv4.icanhazip.com 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}'; }

# Lectura directa /proc - Zero lag
cpu_usage(){
  local a b c d idle total
  read cpu a b c d rest < /proc/stat
  idle1=$d; total1=$((a+b+c+d))
  sleep 0.3
  read cpu a b c d rest < /proc/stat
  idle2=$d; total2=$((a+b+c+d))
  local idle=$((idle2-idle1)) total=$((total2-total1))
  [[ $total -eq 0 ]] && echo "0.0" || awk "BEGIN{printf \"%.1f\", 100*($total-$idle)/$total}"
}

ram_info(){
  local total used available
  total=$(awk '/MemTotal/{print $2}' /proc/meminfo)
  available=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
  used=$((total-available))
  echo "$((used/1024)) $((total/1024)) $((available/1024))"
}

disk_info(){
  df -h / 2>/dev/null | awk 'NR==2{gsub(/G/,"",$2);gsub(/G/,"",$3);gsub(/G/,"",$4);print $2,$3,$4,$5}'
}

bar_graph(){
  local pct=$1 width=${2:-20}
  local filled=$((pct * width / 100))
  local empty=$((width - filled))
  local bar=""
  for ((i=0;i<filled;i++)); do bar+="|"; done
  for ((i=0;i<empty;i++)); do bar+=" "; done
  echo "[$bar ${pct}%]"
}

svc_on(){ systemctl is-active "$1" &>/dev/null && echo -e "${GREEN}ON${NC}" || echo -e "${RED}OFF${NC}"; }

dias_restantes(){
  local exp="$1" hoy_s=$(date +%s) exp_s
  exp_s=$(date -d "$exp" +%s 2>/dev/null || echo 0)
  echo $(( (exp_s - hoy_s) / 86400 ))
}

# Telegram notify
tg_send(){
  local msg="$1"
  local cfg="/etc/SimpleVPS/db/telegram.conf"
  [[ ! -f $cfg ]] && return
  source "$cfg" 2>/dev/null
  [[ -z $TG_TOKEN || -z $TG_CHAT ]] && return
  curl -s -X POST "https://api.telegram.org/bot${TG_TOKEN}/sendMessage" \
    -d chat_id="$TG_CHAT" -d parse_mode="HTML" \
    --data-urlencode text="$msg" &>/dev/null &
}

count_lines(){ [[ -f $1 ]] && wc -l < "$1" || echo 0; }
