#!/bin/bash
# Xray Core - VMess / VLESS / Trojan + WS / gRPC
RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'; BLUE='\033[1;36m'; NC='\033[0m'
DIR="/etc/SimpleVPS"
XRAY_DIR="/usr/local/etc/xray"
UUID=$(cat /proc/sys/kernel/random/uuid 2>/dev/null || python3 -c "import uuid; print(uuid.uuid4())")

echo -e "${YELLOW}[*] Instalando Xray Core...${NC}"
arch=$(uname -m)
case $arch in x86_64) arch="64";; aarch64) arch="arm64-v8a";; *) echo "Arch no soportada"; exit 1;; esac

# Instalar Xray
if [[ ! -f /usr/local/bin/xray ]]; then
  bash -c "$(curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install &>/dev/null \
    || {
      ver="1.8.23"
      wget -qO /tmp/xray.zip "https://github.com/XTLS/Xray-core/releases/download/v${ver}/Xray-linux-${arch}.zip" 2>/dev/null
      unzip -o /tmp/xray.zip -d /tmp/xray_bin &>/dev/null
      mv /tmp/xray_bin/xray /usr/local/bin/xray
      chmod +x /usr/local/bin/xray
      mkdir -p $XRAY_DIR /usr/local/share/xray
      mv /tmp/xray_bin/geo* /usr/local/share/xray/ 2>/dev/null
      rm -rf /tmp/xray.zip /tmp/xray_bin
    }
fi

mkdir -p $XRAY_DIR /var/log/xray
# Cert autofirmado para TLS
if [[ ! -f $XRAY_DIR/cert.pem ]]; then
  openssl req -x509 -nodes -newkey rsa:2048 -keyout $XRAY_DIR/key.pem -out $XRAY_DIR/cert.pem \
    -subj "/CN=www.cloudflare.com" -days 3650 2>/dev/null
fi

cat > $XRAY_DIR/config.json << XEOF
{
  "log": {"loglevel": "warning", "access": "/var/log/xray/access.log", "error": "/var/log/xray/error.log"},
  "inbounds": [
    {
      "tag": "vmess-ws",
      "listen": "0.0.0.0",
      "port": 80,
      "protocol": "vmess",
      "settings": {"clients": [{"id": "${UUID}", "alterId": 0}]},
      "streamSettings": {
        "network": "ws",
        "wsSettings": {"path": "/vmess"}
      }
    },
    {
      "tag": "vmess-ws-tls",
      "listen": "0.0.0.0",
      "port": 443,
      "protocol": "vmess",
      "settings": {"clients": [{"id": "${UUID}", "alterId": 0}]},
      "streamSettings": {
        "network": "ws",
        "security": "tls",
        "tlsSettings": {"certificates": [{"certificateFile": "${XRAY_DIR}/cert.pem", "keyFile": "${XRAY_DIR}/key.pem"}]},
        "wsSettings": {"path": "/vmess"}
      }
    },
    {
      "tag": "vless-ws",
      "listen": "0.0.0.0",
      "port": 8082,
      "protocol": "vless",
      "settings": {
        "clients": [{"id": "${UUID}", "flow": ""}],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "ws",
        "wsSettings": {"path": "/vless"}
      }
    },
    {
      "tag": "trojan-ws",
      "listen": "0.0.0.0",
      "port": 8443,
      "protocol": "trojan",
      "settings": {"clients": [{"password": "${UUID}"}]},
      "streamSettings": {
        "network": "ws",
        "security": "tls",
        "tlsSettings": {"certificates": [{"certificateFile": "${XRAY_DIR}/cert.pem", "keyFile": "${XRAY_DIR}/key.pem"}]},
        "wsSettings": {"path": "/trojan"}
      }
    },
    {
      "tag": "vless-grpc",
      "listen": "0.0.0.0",
      "port": 2053,
      "protocol": "vless",
      "settings": {
        "clients": [{"id": "${UUID}"}],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "grpc",
        "security": "tls",
        "tlsSettings": {"certificates": [{"certificateFile": "${XRAY_DIR}/cert.pem", "keyFile": "${XRAY_DIR}/key.pem"}]},
        "grpcSettings": {"serviceName": "grpc"}
      }
    }
  ],
  "outbounds": [{"protocol": "freedom", "tag": "direct"}, {"protocol": "blackhole", "tag": "block"}]
}
XEOF

cat > /etc/systemd/system/xray.service << 'SYSEOF'
[Unit]
Description=Xray Service
After=network.target
[Service]
Type=simple
ExecStart=/usr/local/bin/xray run -config /usr/local/etc/xray/config.json
Restart=on-failure
RestartSec=3
LimitNOFILE=1048576
[Install]
WantedBy=multi-user.target
SYSEOF

systemctl daemon-reload
systemctl enable xray &>/dev/null
systemctl restart xray &>/dev/null

IP=$(curl -s --max-time 3 ipv4.icanhazip.com 2>/dev/null || hostname -I | awk '{print $1}')
echo -e "${GREEN}[✓] Xray Core instalado${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  UUID/Password: ${YELLOW}${UUID}${NC}"
echo -e "  VMess WS:      ${YELLOW}${IP}:80${NC}  path=/vmess"
echo -e "  VMess WSS:     ${YELLOW}${IP}:443${NC} path=/vmess (TLS)"
echo -e "  VLESS WS:      ${YELLOW}${IP}:8082${NC} path=/vless"
echo -e "  Trojan WSS:    ${YELLOW}${IP}:8443${NC} path=/trojan (TLS)"
echo -e "  VLESS gRPC:    ${YELLOW}${IP}:2053${NC} service=grpc (TLS)"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "$UUID" > $DIR/db/xray.uuid
