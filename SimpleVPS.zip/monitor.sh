#!/bin/bash
# Monitor en tiempo real - SimpleVPS
DIR="/etc/SimpleVPS"
DB="${DIR}/db/users.db"
RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'; BLUE='\033[1;36m'; WHITE='\033[1;37m'; NC='\033[0m'

trap 'echo -e "\n${YELLOW}Monitor detenido${NC}"; exit 0' INT TERM

while true; do
  clear
  echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${YELLOW}    MONITOR EN TIEMPO REAL  $(date +%H:%M:%S)${NC}"
  echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo ""
  echo -e "  ${WHITE}Sesiones activas (who):${NC}"
  who 2>/dev/null | while read l; do echo -e "    $l"; done
  echo ""
  echo -e "  ${WHITE}Usuarios SSH:${NC}"
  printf "  %-14s %-8s %-6s %-12s %s\n" "USUARIO" "ONLINE" "LIM" "EXPIRA" "DIAS"
  echo -e "  ${BLUE}──────────────────────────────────────${NC}"
  hoy=$(date +%Y-%m-%d)
  hoy_s=$(date -d "$hoy" +%s 2>/dev/null || date +%s)
  if [[ -s $DB ]]; then
    while IFS='|' read -r u p e l c; do
      on=$(ps aux 2>/dev/null | grep -c "sshd: ${u}@" || echo 0)
      exp_s=$(date -d "$e" +%s 2>/dev/null || echo 0)
      dias=$(( (exp_s - hoy_s) / 86400 ))
      [[ $dias -lt 0 ]] && dias_c="${RED}${dias}${NC}" || dias_c="${GREEN}${dias}${NC}"
      [[ $on -gt 0 ]] && on_c="${GREEN}$on${NC}" || on_c="$on"
      printf "  %-14s " "$u"
      echo -ne "$on_c"
      printf "        %-6s %-12s " "$l" "$e"
      echo -e "$dias_c"
    done < $DB
  else
    echo -e "  ${RED}Sin usuarios${NC}"
  fi
  echo ""
  echo -e "  ${WHITE}Servicios:${NC}"
  for s in sshd dropbear xray hysteria badvpn wsproxy slowdns; do
    st=$(systemctl is-active $s 2>/dev/null || echo off)
    [[ $st == "active" ]] && echo -e "    $s: ${GREEN}$st${NC}" || echo -e "    $s: ${RED}$st${NC}"
  done
  echo ""
  echo -e "  ${YELLOW}Ctrl+C para salir | Actualiza cada 5s${NC}"
  sleep 5
done
