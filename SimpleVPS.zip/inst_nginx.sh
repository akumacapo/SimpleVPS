#!/bin/bash
# Nginx Gateway - Gestion puertos 80 y 443
RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'; BLUE='\033[1;36m'; NC='\033[0m'
DIR=/etc/SimpleVPS

echo -e "${YELLOW}[*] Instalando Nginx Gateway...${NC}"
apt-get install -y nginx &>/dev/null

# Liberar 80/443 de otros servicios si hace falta (Xray puede moverse)
echo -ne "  Dominio (Enter=solo IP): "; read DOMAIN
[[ -z $DOMAIN ]] && DOMAIN="_"

# Stream + HTTP proxy basico hacia Xray/SSH
cat > /etc/nginx/nginx.conf << 'NGX'
user www-data;
worker_processes auto;
pid /run/nginx.pid;
events { worker_connections 4096; }
http {
  sendfile on;
  tcp_nopush on;
  keepalive_timeout 65;
  server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    location /vmess {
      proxy_pass http://127.0.0.1:10080;
      proxy_http_version 1.1;
      proxy_set_header Upgrade $http_upgrade;
      proxy_set_header Connection "upgrade";
      proxy_set_header Host $host;
    }
    location /vless {
      proxy_pass http://127.0.0.1:10081;
      proxy_http_version 1.1;
      proxy_set_header Upgrade $http_upgrade;
      proxy_set_header Connection "upgrade";
      proxy_set_header Host $host;
    }
    location /trojan {
      proxy_pass http://127.0.0.1:10082;
      proxy_http_version 1.1;
      proxy_set_header Upgrade $http_upgrade;
      proxy_set_header Connection "upgrade";
      proxy_set_header Host $host;
    }
    location / {
      return 200 'SimpleVPS Gateway';
      add_header Content-Type text/plain;
    }
  }
}
stream {
  # TLS passthrough opcional 443 -> xray
  server {
    listen 443;
    proxy_pass 127.0.0.1:10443;
    proxy_timeout 10s;
  }
}
NGX

# Si Xray esta en 80/443, sugerir mover inbounds a 10080 etc - documentado
systemctl enable nginx &>/dev/null
systemctl restart nginx &>/dev/null

if systemctl is-active nginx &>/dev/null; then
  echo -e "${GREEN}[✓] Nginx Gateway activo${NC}"
  echo -e "  :80  → /vmess /vless /trojan → backends locales"
  echo -e "  :443 → stream passthrough 127.0.0.1:10443"
  echo "$DOMAIN" > $DIR/db/domain.txt
else
  echo -e "${RED}[!] Nginx no arranco (¿puerto ocupado?)${NC}"
  journalctl -u nginx -n 5 --no-pager 2>/dev/null
fi
