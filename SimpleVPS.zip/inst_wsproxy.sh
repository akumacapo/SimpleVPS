#!/bin/bash
# WebSocket Proxy - Python y Go
RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'; BLUE='\033[1;36m'; NC='\033[0m'
DIR="/etc/SimpleVPS"
WS_DIR="/etc/ws-proxy"

echo -e "${YELLOW}[*] Instalando WebSocket Proxy...${NC}"
mkdir -p $WS_DIR

echo -e "  ${GREEN}[1]${NC} Python (websocket-proxy simple)"
echo -e "  ${GREEN}[2]${NC} Go (wsproxy binario)"
echo -ne "  Opcion [1]: "; read tipo
[[ -z $tipo ]] && tipo=1

echo -ne "  Puerto WS [8080]: "; read PORT
[[ -z $PORT ]] && PORT=8080
echo -ne "  Puerto destino SSH [22]: "; read DEST
[[ -z $DEST ]] && DEST=22

if [[ $tipo == "1" ]]; then
  # Python WS Proxy
  apt-get install -y python3 python3-pip &>/dev/null
  pip3 install websockets -q 2>/dev/null || pip3 install websockets --break-system-packages -q 2>/dev/null

  cat > $WS_DIR/wsproxy.py << 'PYEOF'
#!/usr/bin/env python3
import asyncio, websockets, socket, sys, os

LISTEN_PORT = int(os.environ.get("WS_PORT", "8080"))
TARGET_HOST = "127.0.0.1"
TARGET_PORT = int(os.environ.get("WS_DEST", "22"))

async def handle(ws):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((TARGET_HOST, TARGET_PORT))
        sock.setblocking(False)
        loop = asyncio.get_event_loop()
        async def tcp_to_ws():
            while True:
                data = await loop.sock_recv(sock, 65536)
                if not data: break
                await ws.send(data)
        async def ws_to_tcp():
            async for msg in ws:
                if isinstance(msg, str): msg = msg.encode()
                await loop.sock_sendall(sock, msg)
        await asyncio.gather(tcp_to_ws(), ws_to_tcp())
    except Exception:
        pass
    finally:
        try: sock.close()
        except: pass

async def main():
    async with websockets.serve(handle, "0.0.0.0", LISTEN_PORT, ping_interval=None):
        print(f"WS Proxy listening on :{LISTEN_PORT} -> {TARGET_HOST}:{TARGET_PORT}")
        await asyncio.Future()

asyncio.run(main())
PYEOF
  chmod +x $WS_DIR/wsproxy.py

  cat > /etc/systemd/system/wsproxy.service << SYSEOF
[Unit]
Description=WebSocket Proxy Python
After=network.target
[Service]
Type=simple
Environment=WS_PORT=${PORT}
Environment=WS_DEST=${DEST}
ExecStart=/usr/bin/python3 ${WS_DIR}/wsproxy.py
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
SYSEOF

else
  # Go-style simple proxy usando socat + websocat si disponible, o Python fallback
  if ! command -v websocat &>/dev/null; then
    # Instalar websocat si es posible
    wget -qO /usr/local/bin/websocat "https://github.com/vi/websocat/releases/download/v1.12.0/websocat.x86_64-unknown-linux-musl" 2>/dev/null
    chmod +x /usr/local/bin/websocat 2>/dev/null
  fi
  if command -v websocat &>/dev/null; then
    cat > /etc/systemd/system/wsproxy.service << SYSEOF
[Unit]
Description=WebSocket Proxy Go/websocat
After=network.target
[Service]
Type=simple
ExecStart=/usr/local/bin/websocat -s 0.0.0.0:${PORT} --binary tcp:127.0.0.1:${DEST}
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
SYSEOF
  else
    echo -e "${YELLOW}websocat no disponible, usando Python${NC}"
    exec bash $0  # re-run with python - simplified: just use python path
  fi
fi

systemctl daemon-reload
systemctl enable wsproxy &>/dev/null
systemctl restart wsproxy &>/dev/null

IP=$(curl -s --max-time 3 ipv4.icanhazip.com 2>/dev/null || hostname -I | awk '{print $1}')
echo -e "${GREEN}[✓] WebSocket Proxy instalado${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "  Puerto WS:  ${YELLOW}${PORT}${NC}"
echo -e "  Destino:    ${YELLOW}127.0.0.1:${DEST}${NC}"
echo -e "  Payload:    ${YELLOW}GET / HTTP/1.1[crlf]Host: ${IP}[crlf]Upgrade: websocket[crlf][crlf]${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "${PORT}|${DEST}" > $DIR/db/wsproxy.conf
