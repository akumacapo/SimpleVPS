#!/bin/bash
DB="/etc/SimpleVPS/db/users.db"
XDB="/etc/SimpleVPS/db/xray_users.db"
LOG="/etc/SimpleVPS/tmp/cleaner.log"
hoy=$(date +%Y-%m-%d)
tmp=$(mktemp); count=0
[[ -f $DB ]] && while IFS='|' read -r user pass expira limite creado status; do
  [[ -z $user ]] && continue
  if [[ "$expira" < "$hoy" ]]; then
    pkill -u "$user" 2>/dev/null; passwd -l "$user" 2>/dev/null
    userdel -r "$user" 2>/dev/null
    echo "$(date '+%F %T') EXP SSH $user" >> $LOG; ((count++))
  else
    echo "${user}|${pass}|${expira}|${limite}|${creado}|${status:-active}" >> $tmp
  fi
done < $DB
[[ -f $tmp ]] && mv $tmp $DB
tmp=$(mktemp)
[[ -f $XDB ]] && while IFS='|' read -r n u e c s; do
  [[ -z $n ]] && continue
  if [[ "$e" < "$hoy" ]]; then
    echo "$(date '+%F %T') EXP XRAY $n" >> $LOG; ((count++))
  else
    echo "${n}|${u}|${e}|${c}|${s:-active}" >> $tmp
  fi
done < $XDB
[[ -f $tmp ]] && mv $tmp $XDB
echo "$(date '+%F %T') Limpieza: $count eliminados" >> $LOG
# Telegram si existe
source /etc/SimpleVPS/lib/funcoes.sh 2>/dev/null
[[ $count -gt 0 ]] && tg_send "🧹 Limpieza: $count cuentas expiradas eliminadas" 2>/dev/null
